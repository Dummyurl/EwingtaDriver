package ewingta.domesticlogistic.driver.models;

public class OTPResponse {
    private String status;
    private String Statuss;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatuss() {
        return Statuss;
    }

    public void setStatuss(String statuss) {
        Statuss = statuss;
    }
}
