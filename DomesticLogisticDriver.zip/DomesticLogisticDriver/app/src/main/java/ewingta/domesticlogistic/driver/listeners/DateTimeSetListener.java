package ewingta.domesticlogistic.driver.listeners;

import ewingta.domesticlogistic.driver.models.Time;

/**
 * Created by FAMILY on 14-12-2017.
 */

public interface DateTimeSetListener {
    void onDateTimeSet(String date, Time time);
}
