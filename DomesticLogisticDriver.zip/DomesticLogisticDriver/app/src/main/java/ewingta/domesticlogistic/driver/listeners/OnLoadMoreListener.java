package ewingta.domesticlogistic.driver.listeners;

public interface OnLoadMoreListener {
    void onLoadMore();
}
