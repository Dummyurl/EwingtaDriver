package ewingta.domesticlogistic.driver.utils;

public class CrashUtil {
    public static void report(Exception e) {

    }
}
