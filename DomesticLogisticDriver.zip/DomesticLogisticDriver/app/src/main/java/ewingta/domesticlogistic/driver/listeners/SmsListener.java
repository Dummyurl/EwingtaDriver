package ewingta.domesticlogistic.driver.listeners;

public interface SmsListener {
    void messageReceived(String messageText);
}
